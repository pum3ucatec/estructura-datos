1. Crear una rama 
```
GastonQuelali/Practica2
```
2. Crear un archivo `Biografia.md` y una carpeta de `imagenes` dentro de `practicas/practica2`, el archivo `.md` tiene que utilzar headings, enlaces, imagenes, listar ordenadas, listas desordenadas (vinetas).
